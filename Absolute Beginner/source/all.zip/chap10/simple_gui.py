# Simple GUI
# Demonstrates creating a window
# Michael Dawson - 6/5/03

from Tkinter import *

# create the root window
root = Tk()

# modify the window
root.title("Simple GUI")
root.geometry("200x100")

# kick off the window's event-loop
root.mainloop()
