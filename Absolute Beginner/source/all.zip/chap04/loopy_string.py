# Loopy String
# Demonstrates the for loop with a string
# Michael Dawson - 1/26/03

word = raw_input("Enter a word: ")

print "\nHere's each letter in your word:"
for letter in word:
    print letter

raw_input("\n\nPress the enter key to exit.")
