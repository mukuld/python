# Random Access
# Demonstrates string indexing
# Michael Dawson - 1/27/03

import random

word = "index"
print "The word is: ", word, "\n"

high = len(word)
low = -len(word)

for i in range(10):
    position = random.randrange(low, high)
    print "word[", position, "]\t", word[position]

raw_input("\n\nPress the enter key to exit.")
