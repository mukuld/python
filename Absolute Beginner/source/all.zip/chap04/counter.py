# Counter
# Demonstrates the range() function
# Michael Dawson - 1/26/03

print "Counting:"
for i in range(10):
    print i,

print "\n\nCounting by fives:"
for i in range(0, 50, 5):
    print i,

print "\n\nCounting backwards:"
for i in range(10, 0, -1):
    print i,

raw_input("\n\nPress the enter key to exit.\n")
