# Greeter
# Demonstrates the use of a variable
# Michael Dawson 1/13/03

name = "Larry"

print name

print "Hi, " + name

raw_input("\n\nPress the enter key to exit.")
