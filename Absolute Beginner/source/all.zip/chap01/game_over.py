# Game Over
# Demonstrates the print command
# Michael Dawson - 12/26/02

print "Game Over"

raw_input("\n\nPress the enter key to exit.")
