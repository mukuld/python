# Message Analyzer
# Demonstrates the len() function and the in operator
# Michael Dawson - 1/26/03

message = raw_input("Enter a message: ")

print "\nThe length of your message is:", len(message)

print "\nThe most common letter in the English language, 'e',",
if "e" in message:
    print "is in your message."
else:
    print "is not in your message."

raw_input("\n\nPress the enter key to exit.")

