# Fancy Credits
# Demonstrates escape sequences
# Michael Dawson 1/11/03

# sound the system bell
print "\a"

print "\t\t\tFancy Credits"

print "\t\t\t \\ \\ \\ \\ \\ \\ \\"
print "\t\t\t\tby"
print "\t\t\tMichael Dawson"
print "\t\t\t \\ \\ \\ \\ \\ \\ \\"

print "\nSpecial thanks goes out to:"
print "My hair stylist, Henry \'The Great\', who never says \"can\'t\"."

raw_input("\n\nPress the enter key to exit.")

