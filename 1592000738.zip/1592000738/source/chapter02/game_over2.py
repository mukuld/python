# Game Over - Version 2
# Demonstrates the use of quotes in strings
# Michael Dawson - 1/9/03

print "Program 'Game Over' 2.0"

print \
"""
 _____       ___       ___  ___   _____  
/  ___|     /   |     /   |/   | |  ___| 
| |        / /| |    / /|   /| | | |__   
| |  _    / ___ |   / / |__/ | | |  __|  
| |_| |  / /  | |  / /       | | | |___  
\_____/ /_/   |_| /_/        |_| |_____|
 
 _____   _     _   _____   _____   
/  _  \ | |   / / |  ___| |  _  \  
| | | | | |  / /  | |__   | |_| |  
| | | | | | / /   |  __|  |  _  /  
| |_| | | |/ /    | |___  | | \ \  
\_____/ |___/     |_____| |_|  \_\

"""

raw_input("\n\nPress the enter key to exit.")
