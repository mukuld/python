                         THE PYGAME PACKAGE
                        1.5.6 for Python 2.2.x

Dependencies
------------

To install the pygame package, you must first install Python.

Installation
------------

To install pygame, simply run the pygame set-up program, pygame-1.5.6.win32-
py2.2.exe, by double-clicking it, and follow the prompts.

If you get a message that Python can't be found, you may need to update your 
PATH to include the folder in which you installed Python.


Testing
-------

Start the Python interpreter and type:

import pygame

If this line produces no errors, you've successfully installed the package. 

Official Site
-------------

For more information, visit the official pygame web site at 
http://www.pygame.org.
